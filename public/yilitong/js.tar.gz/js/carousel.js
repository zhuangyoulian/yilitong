var wrap1 = document.querySelector(".wrap1");
			var next = document.querySelector(".arrow_right");
			var prev = document.querySelector(".arrow_left");
			// 手动轮播
			next.onclick = function() {
				//console.log("click next...");
				next_pic();
			}
			prev.onclick = function() {
				//console.log("click prev...");
				prev_pic();
			}

			function next_pic() {
				var newLeft;
				if (wrap1.style.left === "-4560px") {
					newLeft = -1520;
				} else {
					newLeft = parseInt(wrap1.style.left) - 760;
				}
				wrap1.style.left = newLeft + "px";

				index++;
				if (index > 4) {
					index = 0;
				}
				showCurrentDot();
			}

			function prev_pic() {
				var newLeft;
				if (wrap1.style.left === "0px") {
					newLeft = -3040;
				} else {
					newLeft = parseInt(wrap1.style.left) + 760;
				}
				wrap1.style.left = newLeft + "px";

				index--;
				if (index < 0) {
					index = 4;
				}
				showCurrentDot();
			}
			// 自动轮播
			var timer = null;

			function autoPlay() {
				timer = setInterval(function() {
					next_pic();
				}, 5000);
			}
			autoPlay();
			//移入停止播放,移出播放
			var container = document.querySelector(".container");
			container.onmouseenter = function() {
				clearInterval(timer);
			}
			container.onmouseleave = function() {
				autoPlay();
			}
			// 小圆点动画
			var index = 0;
			var dots = document.getElementById("uniqueness").getElementsByTagName("span");
			function showCurrentDot() {
				for (var i = 0, len = dots.length; i < len; i++) {
					dots[i].className = "";
				}
				dots[index].className = "on";
			}
			showCurrentDot();
			// 小圆点点击事件
			for (var i = 0, len = dots.length; i < len; i++) {
				(function(i) {
					dots[i].onclick = function() {
						var dis = index - i;
						// 和使用prev和next相同，在最开始的照片5和最终的照片1在使用时会出现问题，
						// 导致符号和位数的出错，做相应地处理即可

						if (index == 4 && parseInt(wrap1.style.left) !== -3800) {
							dis = dis - 5;
						}
						if (index == 0 && parseInt(wrap1.style.left) !== -760) {
							dis = dis + 5;
						}
						//console.log('index:'+index+'|wrap1.style.left:'+wrap1.style.left,'|dis:'+dis);
						wrap1.style.left = (parseInt(wrap1.style.left) + dis * 760) + "px";
						//console.log(wrap1.style.left);
						index = i;
						showCurrentDot();
					}
				})(i);
			}